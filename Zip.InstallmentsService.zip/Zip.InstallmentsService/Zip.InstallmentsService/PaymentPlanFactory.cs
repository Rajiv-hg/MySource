using System;
 

namespace Zip.InstallmentsService
{
    /// <summary>
    /// This class is responsible for building the PaymentPlan according to the Zip product definition.
    /// </summary>
    public class PaymentPlanFactory
    {
        /// <summary>
        /// Builds the PaymentPlan instance.
        /// </summary>
        /// <param name="purchaseAmount">The total amount for the purchase that the customer is making.</param>
        /// <returns>The PaymentPlan created with all properties set.</returns>
        public PaymentPlan CreatePaymentPlan(decimal purchaseAmount)
        {
            // TODO
            DateTime lastPaymentDueDate = new DateTime(2022, 01, 01); 
            DateTime nextPaymentDueDate = new DateTime(2022, 01, 01);
            int totalInstallments = 4;
            double installmentFrequency = 14;
            try
            {
                PaymentPlan paymentPlan = new PaymentPlan();
                paymentPlan.Id = Guid.NewGuid();
                paymentPlan.PurchaseAmount = purchaseAmount;
                Installment[] installments = new Installment[totalInstallments];
                for (int i = 0; i < totalInstallments; i++)
                {
                    Installment installment = new Installment();
                    installment.Id = Guid.NewGuid();
                    installment.Amount = purchaseAmount / totalInstallments;
                    nextPaymentDueDate = lastPaymentDueDate.AddDays(installmentFrequency);
                    installment.DueDate = nextPaymentDueDate;
                    installments[i] = installment;
                    lastPaymentDueDate = nextPaymentDueDate;
                }
                paymentPlan.Installments = installments;
                return paymentPlan;
            }
            catch (Exception)
            {

                throw ;
            }
        }
    }
}
