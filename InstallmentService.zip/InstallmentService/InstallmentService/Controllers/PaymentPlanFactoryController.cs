﻿using Microsoft.AspNetCore.Mvc;
using InstallmentService.Models;
using System.Threading.Tasks;
using System;
namespace InstallmentService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentPlanFactoryController : Controller
    {
        /// <summary>
        /// Function calculates the Instalments
        /// </summary>
        /// <param name="totalInstallments"> Number of Installments </param>
        /// <param name="purchaseAmount">Purchase Amount</param>
        /// <param name="installmentPeriod"> Duration</param>
        /// <returns></returns>
        [HttpGet]
        public PaymentPlan CreatePaymentPlan(int totalInstallments,decimal purchaseAmount, int installmentPeriod)
        {

            DateTime lastPaymentDueDate = DateTime.UtcNow;
            DateTime nextPaymentDueDate = DateTime.UtcNow;
            Installment[] installments = new Installment[totalInstallments];
            for (int i = 0; i < totalInstallments; i++)
            {
                Installment inst = new Installment();
                inst.Id = Guid.NewGuid();
                inst.Amount = purchaseAmount / totalInstallments;
                nextPaymentDueDate = lastPaymentDueDate.AddDays(installmentPeriod);
                inst.DueDate = nextPaymentDueDate;
                installments[i] = inst;
                lastPaymentDueDate = nextPaymentDueDate;
            }
            PaymentPlan pmtPlan = new PaymentPlan();
            pmtPlan.Id = Guid.NewGuid();
            pmtPlan.Installments = installments;
            pmtPlan.PurchaseAmount = purchaseAmount;
            if (pmtPlan==null)
            {
                return null;
            }
            return pmtPlan;

        }
                 
    }
}
