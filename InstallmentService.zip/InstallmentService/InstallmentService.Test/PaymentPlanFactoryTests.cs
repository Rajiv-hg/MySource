
using Xunit;

using InstallmentService;

namespace InstallmentService.Test
{
    public class PaymentPlanFactoryTests
    {
  
        public void ReturnPaymentPlan()
        {
            var paymentPlanFactory = new InstallmentService.Controllers.PaymentPlanFactoryController();
            paymentPlanFactory.CreatePaymentPlan(4, 200, 14);
        }
    }
}
