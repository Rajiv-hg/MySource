﻿using InstallmentService.Controllers;
using Moq;
using System;
using Xunit;

namespace InstallmentService.Tests.Controllers
{
    public class PaymentPlanFactoryControllerTests
    {
        private MockRepository mockRepository;



        public PaymentPlanFactoryControllerTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private PaymentPlanFactoryController CreatePaymentPlanFactoryController()
        {
            return new PaymentPlanFactoryController();
        }

        [Fact]
        public void CreatePaymentPlan_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var paymentPlanFactoryController = this.CreatePaymentPlanFactoryController();
            int totalInstallments = 4;
            decimal purchaseAmount = 500;
            int installmentPeriod = 14;

            // Act
            var result = paymentPlanFactoryController.CreatePaymentPlan(
                totalInstallments,
                purchaseAmount,
                installmentPeriod);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
