using Shouldly;
using Xunit;
using InstallmentService.Controllers;
namespace InstallmentService.Tests
{
    public class UnitTest1
    {
        /// <summary>
        /// Pass the parameters Installments,Amount and duration
        /// </summary>
        [Fact]
        public void Return()
        {
            var paymentPlanFactory = new PaymentPlanFactoryController();
            paymentPlanFactory.CreatePaymentPlan(4, 200, 14);
           
            paymentPlanFactory.ShouldNotBeNull();

        }
    }
}
